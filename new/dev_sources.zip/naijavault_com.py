# -*- coding: utf-8 -*-

import re

from six.moves.urllib_parse import parse_qs, urlencode, urlparse

from resources.lib.modules import cleantitle
from resources.lib.modules import client
from resources.lib.modules import client_utils
from resources.lib.modules import scrape_sources
from resources.lib.modules import log_utils

DOM = client_utils.parseDOM

class source:
    def __init__(self):
        self.results = []
        self.domains = ['www.naijavault.com']
        self.base_link = 'https://www.naijavault.com'
        self.search_link = '/?s=%s'
        self.headers = client.dnt_headers
        self.notes = 'testing this'
        

    def movie(self, imdb, tmdb, title, localtitle, aliases, year):
        url = {'imdb': imdb, 'title': title, 'aliases': aliases, 'year': year}
        url = urlencode(url)
        return url


    def tvshow(self, imdb, tmdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        url = {'imdb': imdb, 'tvshowtitle': tvshowtitle, 'aliases': aliases, 'year': year}
        url = urlencode(url)
        return url


    def episode(self, url, imdb, tmdb, tvdb, title, premiered, season, episode):
        if not url:
            return
        url = parse_qs(url)
        url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
        url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
        url = urlencode(url)
        return url


    def sources(self, url, hostDict):
        try:
            if not url:
                return self.results
                
            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            aliases = eval(data['aliases'])
            title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
            season, episode = (data['season'], data['episode']) if 'tvshowtitle' in data else ('0', '0')
            year = data['premiered'].split('-')[0] if 'tvshowtitle' in data else data['year']
            check_term = '%s Season %s' % (title, season) if 'tvshowtitle' in data else title
            check_title = cleantitle.get(check_term)
            search_url = self.base_link + self.search_link % cleantitle.get_utf8(title)
            log_utils.log('search_url=' + repr(search_url), 1)
            r = client.scrapePage(search_url, headers=self.headers).text
            log_utils.log('r1 =' + repr(r), 1)
            # r2 = client.request(search_url, headers=self.headers, output='extended')
            # log_utils.log('r2 =' + repr(r2), 1)
            r = DOM(r, 'div', attrs={'class': 'mh-loop-content mh-clearfix'})
            log_utils.log('r =' + repr(r), 1)
            
            r = [(DOM(i, 'a', ret='href', attrs={'rel': 'bookmark'}),
            DOM(i, 'a', ret='title'),
            DOM(i, 'div', attrs={'class': 'mh-excerpt'})) for i in r]
            # FLATTEN the list
            r = [(i[0][0], i[1][0], i[2][0]) for i in r if len(i[0]) > 0 and len(i[1]) > 0 and len(i[2]) > 0]
            r = [(i[0], client_utils.replaceHTMLCodes(i[1]), client_utils.replaceHTMLCodes(i[2])) for i in r]
            # remove the YEAR and other crap
            # rpattern = r'\s*\(?\b(?:\d{4}|complete|added)\b\)?'
            rpattern = r'\s*\(?\b(?:\d{4}|complete|added|remix)\b\)?|\s*\[(?:zip file|music)\]'
            r = [( i[0], re.sub(rpattern, '', i[1], flags=re.IGNORECASE).strip(), i[2]) for i in r]
            for i in r:
                log_utils.log('i[1].lower() =' + repr(i[1].lower()) + ' ' + i[0], 1)
            
            if 'tvshowtitle' in data:
                log_utils.log('check_title =' + repr(check_title), 1)
                # result_url = [i[0] for i in r if check_title in cleantitle.get(i[1]) and i[0].endswith('series/')]
                result_url = [i[0] for i in r if check_title in cleantitle.get(i[1])]
                # result_url = [i[0] for i in r if 'episode' in i[1].lower()]
                result_url = result_url[0] if result_url else None
                if result_url is None:
                    # try again; Site sucks for TV titles. Names/seasons are wrong, and/or missing info
                    check_title2 = cleantitle.get(title)
                    log_utils.log('check_title2 =' + repr(check_title2), 1)
                    result_url = [i[0] for i in r if check_title2 in cleantitle.get(i[1])]
                    result_url = result_url[0] if result_url else None
                log_utils.log('result_url =' + repr(result_url), 1)
            else:
                log_utils.log('check_title =' + repr(check_title), 1)
                result_urls = [i[0] for i in r if check_title in cleantitle.get(i[1])
                              and cleantitle.match_year(i[0], year)]
                              # and 'movie' in i[1].lower()]
                result_url = result_urls[0] if result_urls else None
                log_utils.log('result_url =' + repr(result_url), 1)
            if result_url is None:
                return
            
            result_link = self.base_link + result_url if result_url.startswith('/') else result_url
            r = client.scrapePage(result_link, headers=self.headers).text
            log_utils.log('r3 =' + repr(r), 1)
            if 'tvshowtitle' in data:
                check_episode = f'S{int(season):02}E{int(episode):02}'
                r = DOM(r, 'a', ret='href', attrs={'id': 'download-button'})
                log_utils.log('r4 =' + repr(r), 1)
                episode_urls = [i for i in r if check_episode in i]
                log_utils.log('episode_urls =' + repr(episode_urls), 1)
                episode_link = episode_urls[0] if episode_urls else None
                if episode_link is None:
                    return
                link = self.base_link + episode_link if episode_link.startswith('/') else episode_link
                log_utils.log('link =' + repr(link), 1)
            else:
                r = DOM(r, 'a', ret='href', attrs={'id': 'download-button'})
                log_utils.log('r14 =' + repr(r), 1)
                if r is None:
                    return
                link = r[0] if r else None
                log_utils.log('link =' + repr(link), 1)
            if link is None:
                return

            if 'downloadwella' in link:
                html = client.request(link, verify=False)
                form = DOM(html, 'form', attrs={'method': 'POST'})[0]
                postdata = dict(zip(DOM(form, 'input', ret='name'), DOM(form, 'input', ret='value')))
                link = client.request(link, headers=self.headers, post=postdata, output='geturl')
                log_utils.log('link =' + repr(link), 1)

            if 'filevault' in link:
                link = client.request(link, headers=self.headers, output='geturl')
                # link = link.replace('?preview', '')
                if link.endswith('?preview'):
                    link = link[:-len('?preview')]
                log_utils.log('link =' + repr(link), 1)
                
            parts = urlparse(link)
            search = set(hostDict)  # include domain in hostDict, so we can use make_item
            if parts.hostname not in search:
                hostDict.append(parts.hostname)
                search.add(parts.hostname)
            if link:
                for source in scrape_sources.process(hostDict, link):
                    self.results.append(source)

            return self.results
        except:
            return self.results


    def resolve(self, url):
        # log_utils.log('url =' + repr(url), 1)
        return url


