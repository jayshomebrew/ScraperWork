I only included the files I changed, and updated.

added devsources folder setting


